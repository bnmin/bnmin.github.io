#!/bin/bash

trainSourceFile=../data/train.pos-chunk-name
trainFeatureFile=../data/train_ner_features.txt

modelFile=../data/ner.model

devSourceFile=../data/dev.pos-chunk
devFeatureFile=../data/dev_ner_features.txt

# compile
javac -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" GenerateFeaturesForNER.java
javac -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" MEtrain.java
javac -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" MEtag.java

# Generate features from training data
java -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" GenerateFeaturesForNER train $trainSourceFile $trainFeatureFile
# Train a MaxEnt model
java -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" MEtrain $trainFeatureFile $modelFile

# Generate features from dev data
java -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" GenerateFeaturesForNER test $devSourceFile $devFeatureFile
# Decode on the dev data with the model trained from the training data
java -cp ".:../resources/maxent-3.0.0.jar:../resources/trove.jar;" MEtag $devFeatureFile $modelFile ../data/dev.response

# Score system-predicted NER tags agaist gold tags
python score.name.py ../data/dev.name ../data/dev.response 
