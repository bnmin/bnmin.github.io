import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileWriter;


public class GenerateFeaturesForNER {
    public static boolean isCapitalized(String token){
        if(token.length()>1)
            if(Character.isUpperCase(token.charAt(0)))
                return true;

        return false;
    }

    public static void main(String [] args) {
        try {
            boolean isTrain=args[0].trim().equals("train");
            String trainSourceFile=args[1];
            String trainFeatureFile=args[2];

            PrintWriter pw = new PrintWriter(new FileWriter(trainFeatureFile));

            String thisLine = null;
            String prevTag = "NA";

            // open input stream test.txt for reading purpose.
            BufferedReader br = new BufferedReader(new FileReader(trainSourceFile));

            while ((thisLine = br.readLine()) != null) {
                thisLine = thisLine.trim();
                if(thisLine.isEmpty()) {
                    pw.println();
                    continue;
                }

                String [] items = thisLine.split("\t");
                String token = items[0];
                String pos_tag = items[1];
                String phrase_tag = items[2];

                if (isTrain) {
                    String ner_tag = items[3];

                    pw.println(token +
                            "\t" + "pos=" + pos_tag +
                            "\t" + "phrase=" + phrase_tag +
                            "\t" + "IsCap=" + isCapitalized(token) +
                            "\t" + "prevTag=" + prevTag +
                            "\t" + ner_tag);
                    prevTag = ner_tag;
                }
                else {
                    pw.println(token +
                            "\t" + "pos=" + pos_tag +
                            "\t" + "phrase=" + phrase_tag +
                            "\t" + "IsCap=" + isCapitalized(token) +
                            "\t" + "prevTag=@@");
                }
            }

            pw.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
